package gov.usdot.util.dialog;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import java.util.Random;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.codec.binary.Hex;

import com.oss.asn1.AbstractData;
import com.oss.asn1.Coder;
import com.oss.asn1.ControlTableNotFoundException;
import com.oss.asn1.DecodeFailedException;
import com.oss.asn1.DecodeNotSupportedException;
import com.oss.asn1.EncodeFailedException;
import com.oss.asn1.EncodeNotSupportedException;

import gov.usdot.asn1.generated.j2735.J2735;
import gov.usdot.asn1.generated.j2735.dsrc.Position3D;
import gov.usdot.asn1.generated.j2735.semi.AdvisorySituationDataBundle.AsdRecords;
import gov.usdot.asn1.generated.j2735.semi.DataAcceptance;
import gov.usdot.asn1.generated.j2735.semi.DataReceipt;
import gov.usdot.asn1.generated.j2735.semi.GeoRegion;
import gov.usdot.asn1.generated.j2735.semi.RsuAdvisorySituationDataBundle;
import gov.usdot.asn1.generated.j2735.semi.RsuAdvisorySituationDataBundle.AsdBundles;
import gov.usdot.asn1.generated.j2735.semi.RsuAdvisorySituationDataRequest;
import gov.usdot.asn1.generated.j2735.semi.SemiDialogID;
import gov.usdot.asn1.generated.j2735.semi.SemiSequenceID;
import gov.usdot.asn1.j2735.CVSampleMessageBuilder;
import gov.usdot.asn1.j2735.J2735Util;
import gov.usdot.asn1.j2735.TravelerSampleMessageBuilder;
import gov.usdot.asn1.j2735.msg.ids.ConnectedVehicleMessageLookup;
import gov.usdot.cv.common.asn1.TemporaryIDHelper;
import gov.usdot.cv.common.dialog.TrustEstablishment;
import gov.usdot.cv.common.dialog.TrustEstablishmentException;

public class RSUAdvisorySitData {
	
	/***************************************************
	 * Declare Variables
	 ***************************************************/
	
	private static int requestID;
	private static AtomicInteger requestCount = new AtomicInteger();
	private static AtomicInteger replyCounter = new AtomicInteger();
	
	private static final int MAX_PACKET_SIZE = 65535;
	private static final int DEFAULT_TIMEOUT = 8000;
	private static final boolean DEFAULT_VERBOSE = true;
	private static final int DEFAULT_PORT = 46751;
	private static final int MAX_CAPACITY = 10;
	
	private static String replyIP;
	private static String warehouseIP;
	private static int replyPort;
	private static double neLatNum;
	private static double neLongNum;
	private static double seLatNum;
	private static double seLongNum;
	private static long pause;
	private static String path;
	private static String fName;
	private int port = DEFAULT_PORT;
	private int timeout = DEFAULT_TIMEOUT;
	private boolean verbose = DEFAULT_VERBOSE;
	
	private static boolean successful = false;
	private static boolean stop = false;
	private static boolean receipt = false;
	private DatagramSocket sendSock = null;
	private DatagramSocket listenSock = null;
	
	private int currentBundleID  = -1;
	private long bundleTotal = -1; 
	
	private InetAddress sendToHostAddress = null;
	
	private static Coder coder = null;
	
	public static BlockingQueue<DatagramPacket> replies = new ArrayBlockingQueue<DatagramPacket>(MAX_CAPACITY);
	public static ExecutorService RSUService = Executors.newSingleThreadExecutor();
	
	public static BlockingQueue<DatagramPacket> validation = new ArrayBlockingQueue<DatagramPacket>(MAX_CAPACITY);
	public static ExecutorService RSUValidService = Executors.newSingleThreadExecutor();
	
	/***************************************************
	 * Main required functions/procedures
	 ***************************************************/
		
	public RSUAdvisorySitData() throws RSUAdvisorySitDataException {
		initialize();
		RSUValidService.execute(new RSUAdvisoryValidationWorker());
		replyPort = getReplyPort();
	}
	
	private void initialize() throws RSUAdvisorySitDataException {
		try {
			J2735.initialize();
			coder = J2735.getBERCoder();
			if ( verbose )
				coder.enableEncoderDebugging();
		} catch (ControlTableNotFoundException ex) {
			throw new RSUAdvisorySitDataException("Could't initialize J2735 parser due to ControlTableNotFoundException", ex);
		} catch (com.oss.asn1.InitializationException ex) {
			throw new RSUAdvisorySitDataException("Could't initialize J2735 parser due to com.oss.asn1.InitializationException", ex);
		}
	}
	
	public int request() throws RSUAdvisorySitDataException {
		try {
			TrustEstablishment.establishTrust(coder, SemiDialogID.advSitDatDistRSE, requestID, sendToHostAddress, port, InetAddress.getByName(replyIP), replyPort);
		} catch (UnknownHostException ex ) {
			//throw new RSUAdvisorySitDataException("", ex);
		} catch (TrustEstablishmentException ex ) {
			//throw new RSUAdvisorySitDataException(String.format("Couldn't establish trust."));
		}
		
		RSUService.execute(new RSUAdvisoryWorker());
		submitRSUAdvisorySitDataRequest(timeout);
		return requestID;
	}
	
	
	private void submitRSUAdvisorySitDataRequest(int timeout)
			throws RSUAdvisorySitDataException {
		RsuAdvisorySituationDataRequest dataRequest = createRSUAdvisorySitDataRequest();
		System.out.print(dataRequest);
		byte[] requestBytes = null;
		try {
			requestBytes = TravelerSampleMessageBuilder
					.messageToEncodedBytes(dataRequest);
		} catch (EncodeFailedException ex) {
			throw new RSUAdvisorySitDataException(
					"Couldn't encode RSUAdvisorySitDataRequest message because encoding failed.",
					ex);
		} catch (EncodeNotSupportedException ex) {
			throw new RSUAdvisorySitDataException(
					"Couldn't encode RSUAdvisorySitDataRequest message because encoding is not supported.",
					ex);
		}

		if (requestBytes == null)
			System.out.printf("Empty request.");

		try {
			DatagramPacket requestPacket = new DatagramPacket(requestBytes,
					requestBytes.length, sendToHostAddress, port);

			if (verbose)
				System.out.printf("Sending UDP packet to host %s port %d\n",
						requestPacket.getAddress().getCanonicalHostName(),
						requestPacket.getPort());
			try {
				sendSock = new DatagramSocket(port);
				sendSock.send(requestPacket);
			} catch (SocketException ex) {
				System.out.println("Couldn't send query because socket time out reached. Reason: "+ ex);
			} catch (IOException ex) {
				System.out.println("Couldn't send query due to IO exception. Reason: "+ ex);
			}
		} finally {
			//do something? close socket?
		}

		while(!stop){
			if (successful) {
				try {
					returnRSUAdvisorySitDataAcceptance(timeout);
					stop = true;
				} catch (RSUAdvisorySitDataException ex) {
					System.out.println(ex.getMessage());
				}
			}
		}
	}
	
	private void returnRSUAdvisorySitDataAcceptance(int timeout) throws RSUAdvisorySitDataException {
		DataAcceptance dataAcceptance = createRSUAdvisorySitDataAcceptance();
		System.out.print(dataAcceptance);
		byte[] requestBytes = null;
		try {
			requestBytes = TravelerSampleMessageBuilder.messageToEncodedBytes(dataAcceptance);
		} catch (EncodeFailedException ex) {
			throw new RSUAdvisorySitDataException(
					"Couldn't encode RSUAdvisorySitDataAcceptance message because encoding failed.", ex);
		} catch (EncodeNotSupportedException ex) {
			throw new RSUAdvisorySitDataException(
					"Couldn't encode RSUAdvisorySitDataAcceptance message because encoding is not supported.", ex);
		}

		if (requestBytes == null)
			System.out.printf("Empty acceptance.");

		try {
			DatagramPacket acceptancePacket = new DatagramPacket(requestBytes,
					requestBytes.length, sendToHostAddress, port);
			
			if (verbose)
				System.out.printf("Sending UDP acceptance packet to host %s port %d\n",
						acceptancePacket.getAddress().getCanonicalHostName(),
						acceptancePacket.getPort());
			sendSock.send(acceptancePacket);
		} catch (SocketTimeoutException ex) {
            System.out.println("Socket time out reached. Reason: " + ex);
	    } catch (SocketException ex) {
	        System.out.println("Socket closed. Reason: " + ex);
	    } catch (IOException ex) {
	    	System.out.println("IO Exception. Reason: " + ex);
	    } finally {
			if ( sendSock != null ) {
				if ( !sendSock.isClosed() )
					sendSock.close();
				sendSock = null;
			}
	    }
	}
	
	public static void printReceipt(DatagramPacket receiptPacket) throws RSUAdvisorySitDataException {

		final byte[] data = receiptPacket.getData();
		final int length = receiptPacket.getLength();

		byte[] receiptBytes = Arrays.copyOfRange(data,receiptPacket.getOffset(), length);

		try {
			AbstractData msg = ConnectedVehicleMessageLookup.lookupMessage(J2735Util.getMessageID(receiptBytes));
			if (msg == null || !(msg instanceof DataReceipt)) {
				System.out.printf("Unexpected response message of type '%s'\n",	msg != null ? msg.getClass().getName() : "unknown");
			}

			AbstractData pdu = J2735Util.decode(coder, receiptBytes);
			DataReceipt receipt = (DataReceipt) pdu;

			System.out.print(receipt);

		} catch (DecodeFailedException ex) {
			System.out.println("Couldn't decode J2735 ASN.1 BER message because decoding failed");
		} catch (DecodeNotSupportedException ex) {
			System.out.println("Couldn't decode J2735 ASN.1 BER message because decoding is not supported");
		}
	}
    		
	/***************************************************
	 * Build Beans
	 ***************************************************/
	
	public RsuAdvisorySituationDataRequest createRSUAdvisorySitDataRequest() throws RSUAdvisorySitDataException {
		return new RsuAdvisorySituationDataRequest(
				SemiDialogID.advSitDatDistRSE, 
				SemiSequenceID.dataReq,
				TemporaryIDHelper.toTemporaryID(requestID), 
			    setServiceRegion(neLatNum,neLongNum,seLatNum,seLongNum));
	}
	
	//need to adjust with new values
	public DataAcceptance createRSUAdvisorySitDataAcceptance() throws RSUAdvisorySitDataException {
		return new DataAcceptance(
				SemiDialogID.advSitDatDistRSE, 
				SemiSequenceID.accept,
				TemporaryIDHelper.toTemporaryID(requestID));
	}
	
	/***************************************************
	 * Other required functions/procedures
	 ***************************************************/
	
	public static void setRequestID() {
		requestID = requestCount.incrementAndGet();
	}
	
	public static int getReplyPort(){
		//Random rand = new Random();
		//int randomNum = rand.nextInt(65535-1024)+1024;
		int randomNum = 46752;
		return randomNum;	
	}
	
	public int getRequestID() {
		return requestID;
	}
	
	public void setSendToHost(String sendToHost) throws RSUAdvisorySitDataException {
		try {
			sendToHostAddress = InetAddress.getByName( sendToHost );
		} catch (UnknownHostException ex) {
			throw new RSUAdvisorySitDataException(String.format("Couldn't get host '%s' by name", sendToHost), ex);
		}
	}
	
	public String getSendToHost() {
		return sendToHostAddress != null ? sendToHostAddress.getHostAddress() : null;
	}
		
	public GeoRegion setServiceRegion(double nw_lat, double nw_lon, double se_lat, double se_lon) {
		Position3D nwCnr = CVSampleMessageBuilder.getPosition3D(nw_lat, nw_lon);
		Position3D seCnr = CVSampleMessageBuilder.getPosition3D(se_lat, se_lon);
		return new GeoRegion(nwCnr,seCnr);
	}
	
	public static void userInputs(){
		
		Properties prop = new Properties();
		InputStream input = null;
		
        try
        {
        	String fileName = "settings.config";            
            input = new FileInputStream(fileName);
            prop.load(input);
            
            warehouseIP=prop.getProperty("WarehouseIP");
			replyIP = prop.getProperty("HostIP");
			replyPort = Integer.parseInt(prop.getProperty("Port"));
			neLatNum = Double.parseDouble(prop.getProperty("NELatitude"));
			neLongNum = Double.parseDouble(prop.getProperty("NELongitude"));
			seLatNum = Double.parseDouble(prop.getProperty("SELatitude"));
			seLongNum = Double.parseDouble(prop.getProperty("SELongitude"));
			fName = prop.getProperty("Filename");
			path = prop.getProperty("SavePath");
			pause = Long.parseLong(prop.getProperty("RequestPause"));

        } catch (FileNotFoundException ex) {
        	System.out.println("Could not find configuration file settings.config.");
        } catch (IOException ex) {
        	System.out.println("Error reading from settings.config. Check all values.");
        } catch (Exception ex) {
        	System.out.println("Error reading from settings.config. Check all values." + ex.getMessage());
        } finally {
        	if(input!=null){
        		try {
        			input.close();
        		} catch (IOException e) {
        			System.out.println("Could not close settings.config.");
        		}
        	}
        }
	}
			
	/***************************************************
	 * Main Method
	 ***************************************************/
	
	public static void main(String[] args) {

		if (args.length < 1) {
			
			userInputs();
			RSUAdvisorySitData rsuRequest=null;
			try {
				rsuRequest = new RSUAdvisorySitData();
				rsuRequest.setSendToHost(warehouseIP);
			} catch (RSUAdvisorySitDataException ex) {
				System.err.printf("Caught RSUSubscriptionException. Reason: %s\n",ex.getMessage());
			}
			

			try {
				setRequestID();
				rsuRequest.request();
			} catch (RSUAdvisorySitDataException e) {
				System.err.printf(
						"Caught RSUSubscriptionException. Reason: %s\n",
						e.getMessage());
			}
			System.out.printf(
					"Data request confirmed with request ID: %d\n",
					rsuRequest.getRequestID());
		}
	}
	
	
	/***************************************************
	 * Nested class 1 for listening
	 ***************************************************/
	
	//How to handle timeout connections/ do I need a finally block?
	
	class RSUAdvisoryWorker implements Runnable {

		@Override
		public void run() {
			
			try {
				listenSock = new DatagramSocket(replyPort);
			} catch (SocketException ex) {
				System.out.println("Socket not established. Reason: " + ex);
			}

			while (true) {
				byte[] responseBytes = new byte[MAX_PACKET_SIZE];
				DatagramPacket responsePacket = new DatagramPacket(responseBytes,
						responseBytes.length);
				try{
				listenSock.receive(responsePacket);
				replies.put(responsePacket);
				} catch (SocketException ex) {
					System.out.println("Socket closed. Reason: " + ex);
					break;
				} catch (IOException ex) {
					System.out.println("IO Exception. Reason: " + ex);
					break;
				} catch (InterruptedException ex) {
					System.out.println("Connection interupted. Reason: " + ex);
					break;
				}

			}

		}

	}
	
	
	/***************************************************
	 * Nested class 2 for validation
	 ***************************************************/
	
	class RSUAdvisoryValidationWorker implements Runnable{
		
		private DatagramPacket currentPacket;
		private List<DatagramPacket> datagramList = new ArrayList<DatagramPacket>();
				
		@Override
		public void run() {
						
			while (true) {
				try {
					currentPacket = replies.take();
					if (currentPacket.getLength() == 0) {
						System.out.print("All bundles received.\n");
						printToFile(datagramList);		 
						continue;
					} else {
						Boolean validation = isValidRSUAdvisorySitDataBundleAndLastBundle(currentPacket);
						if (validation == null || validation == false)
							System.out
									.println("Packet did not pass validation.");
						if (validation == true) {
							if (receipt){
								printReceipt(currentPacket);
								System.out.printf(
										"Got response from host %s port %d\n",
										currentPacket.getAddress()
												.getCanonicalHostName(),
										currentPacket.getPort());
							} else {
							System.out.printf(
									"Got response from host %s port %d\n",
									currentPacket.getAddress()
											.getCanonicalHostName(),
									currentPacket.getPort());
							datagramList.add(currentPacket);
							}
						}
					}
				} catch (RSUAdvisorySitDataException e) {
					System.out.println("Packets not valid. Reason: " + e);
				} catch (Exception e) {
					System.out.println("Connection Interrupted. Reason: " + e);
				}
			}
		}
		
		
		private Boolean isValidRSUAdvisorySitDataBundleAndLastBundle(DatagramPacket responsePacket) throws RSUAdvisorySitDataException {
			if ( responsePacket == null )
				return null;

			final byte[] data = responsePacket.getData();
			if ( data == null )
				return null;
			
			final int length = responsePacket.getLength();	
			if( length <= 0 )
				return null;
			
			byte[] responseBytes = Arrays.copyOfRange(data, responsePacket.getOffset(), length);
			
			try {

				AbstractData msg = ConnectedVehicleMessageLookup.lookupMessage(J2735Util.getMessageID(responseBytes));
				if (msg instanceof DataReceipt){
					receipt = true;
					return true;	
				} else if( msg == null || !(msg instanceof RsuAdvisorySituationDataBundle)) {
					System.out.printf("Unexpected response message of type '%s'\n", msg != null ? msg.getClass().getName() : "unknown");
					return false;
				}
				
				AbstractData pdu = J2735Util.decode(coder, responseBytes);
				RsuAdvisorySituationDataBundle response = (RsuAdvisorySituationDataBundle)pdu;
				AsdBundles bundle = response.getAsdBundles();
				
				
				//will return false for whole packet if there is one bad bundle
							
				for (int i=0; i < bundle.getSize(); i++){
					if ( currentBundleID == -1 ) {
						bundleTotal = response.getBundleCount();
						currentBundleID = TemporaryIDHelper.fromTemporaryID(bundle.get(i).getBundleId());
					} else {
						if ( currentBundleID != TemporaryIDHelper.fromTemporaryID(bundle.get(i).getBundleId()) ) {
							System.out.printf("Unexpected bundle ID %d.", currentBundleID);
							return false;
						}
					}
					
					replyCounter.getAndIncrement();
				}
				
				System.out.print(response);
				
				if (replyCounter.get() == bundleTotal){
					try {
						replies.put(new DatagramPacket(new byte[0], 0));
						successful=true;
					} catch (InterruptedException e) {
						System.out.println("Interruped. Reason: " + e);
					}
				}
				return  replyCounter.get() <= bundleTotal;
				
			} catch (DecodeFailedException ex) {
				System.out.println("Couldn't decode J2735 ASN.1 BER message because decoding failed");
				return false;
			} catch (DecodeNotSupportedException ex) {
				System.out.println("Couldn't decode J2735 ASN.1 BER message because decoding is not supported");
				return false;
			}
		}
		
		public void printToFile(List<DatagramPacket> packetList){
	
			System.out.println("Writing situation data to: " + path + "\\" + fName + "...\n");
			BufferedWriter out = null;
			try {
				out = new BufferedWriter(new FileWriter(path+"\\"+fName,false));

			for(int l=0; l< packetList.size(); l++){
				byte[] message = packetList.get(l).getData(); 
				AbstractData tempMessage = null;
				try {
					tempMessage = J2735Util.decode(coder,message);
				} catch (DecodeFailedException ex) {
					System.out.printf("Couldn't encode RSUAdvisorySitDataBundle message because encoding failed.", ex);
				} catch (DecodeNotSupportedException ex) {
					System.out.printf("Couldn't decode RSUAdvisorySitDataBundle message because decoding is not supported.", ex);
				}
				RsuAdvisorySituationDataBundle msg = (RsuAdvisorySituationDataBundle) tempMessage;
				if (msg instanceof RsuAdvisorySituationDataBundle) {
					String output = new String();
					AsdBundles bundle = msg.getAsdBundles();
						for (int h = 0; h < bundle.getSize(); h++) {
							AsdRecords asd = bundle.get(h).getAsdRecords();
							for (int i = 0; i < asd.getSize(); i++) {

								long type = asd.get(i).getBroadcastInst()
										.getBiType().longValue();
								int typeInt = (int) type;
								String typeName = new String();
								switch (typeInt) {
								case 0:
									typeName = "SPAT";
									break;
								case 1:
									typeName = "MAP";
									break;
								case 2:
									typeName = "TIM";
									break;
								case 3:
									typeName = "EV";
									break;
								default:
									typeName = "INVALID";
									break;
								}

								byte[] psID = asd.get(i).getBroadcastInst()
										.getBiPsid().byteArrayValue();
								String psIDName = Hex.encodeHexString(psID);

								byte[] priority = asd.get(i).getBroadcastInst()
										.getBiPriority().byteArrayValue();
								String priorityName = Hex
										.encodeHexString(priority);

								long mode = asd.get(i).getBroadcastInst()
										.getBiTxMode().longValue();
								int modeInt = (int) mode;
								String modeName = new String();
								switch (modeInt) {
								case 0:
									modeName = "CONT";
									break;
								case 1:
									modeName = "ALT";
									break;
								default:
									modeName = "INVALID";
									break;
								}

								long channel = asd.get(i).getBroadcastInst()
										.getBiTxChannel().longValue();
								int channelInt = (int) channel;
								String channelName = new String();
								switch (channelInt) {
								case 0:
									channelName = "CCH";
									break;
								case 1:
									channelName = "SCH";
									break;
								case 2:
									channelName = "172";
									break;
								case 3:
									channelName = "174";
									break;
								case 4:
									channelName = "176";
									break;
								case 5:
									channelName = "178";
									break;
								case 6:
									channelName = "180";
									break;
								case 7:
									channelName = "182";
									break;
								case 8:
									channelName = "184";
									break;
								}

								String startDate = ""
										+ asd.get(i).getBroadcastInst()
												.getBiDeliveryStart()
												.getMonth().intValue()
										+ "/"
										+ asd.get(i).getBroadcastInst()
												.getBiDeliveryStart().getDay()
												.intValue()
										+ "/"
										+ asd.get(i).getBroadcastInst()
												.getBiDeliveryStart().getYear()
												.intValue()
										+ ", "
										+ asd.get(i).getBroadcastInst()
												.getBiDeliveryStart().getHour()
												.intValue()
										+ ":"
										+ asd.get(i).getBroadcastInst()
												.getBiDeliveryStart()
												.getMinute().intValue();

								String stopDate = ""
										+ asd.get(i).getBroadcastInst()
												.getBiDelievryStop().getMonth()
												.intValue()
										+ "/"
										+ asd.get(i).getBroadcastInst()
												.getBiDelievryStop().getDay()
												.intValue()
										+ "/"
										+ asd.get(i).getBroadcastInst()
												.getBiDelievryStop().getYear()
												.intValue()
										+ ", "
										+ asd.get(i).getBroadcastInst()
												.getBiDelievryStop().getHour()
												.intValue()
										+ ":"
										+ asd.get(i).getBroadcastInst()
												.getBiDelievryStop()
												.getMinute().intValue();

								byte[] advMsg = asd.get(i).getAdvisoryMessage()
										.byteArrayValue();
								String advMsgName = Hex.encodeHexString(advMsg);

								output = "" + "Version=0.5;" + "Type="
										+ typeName
										+ ";"
										+ "PSID="
										+ psIDName
										+ ";"
										+ "Priority="
										+ priorityName
										+ ";"
										+ "TxMode="
										+ modeName
										+ ";"
										+ "TxChannel="
										+ channelName
										+ ";"
										+ "TxInterval="
										+ asd.get(i).getBroadcastInst()
												.getBiTxInterval()
										+ ";"
										+ "DeliveryStart="
										+ startDate
										+ ";"
										+ "DeliveryStop="
										+ stopDate
										+ ";"
										+ "Signature="
										+ asd.get(i).getBroadcastInst()
												.getBiSignature()
										+ ";"
										+ "Encryption="
										+ asd.get(i).getBroadcastInst()
												.getBiEncryption() + ";"
										+ "Payload=" + advMsgName + ";";
								out.write(output);
								out.newLine();
							}
						}
					}
				}
			} catch (IOException e) {
				System.out.println("Couldn't create file. " + e);
			} finally {
				if (out != null) {
					try {
						out.flush();
					} catch (Exception ignore) {
					}
				}

				if (out != null) {
					try {
						out.close();
						packetList.clear();
					} catch (Exception ignore) {
					}
				}
			}
		}
	}
}
