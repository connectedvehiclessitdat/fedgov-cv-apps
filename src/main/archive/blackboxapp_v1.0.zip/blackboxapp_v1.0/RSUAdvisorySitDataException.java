package gov.usdot.util.dialog;

import gov.usdot.cv.common.subscription.response.ResponseCode;

public class RSUAdvisorySitDataException extends Exception {
	
	private static final long serialVersionUID = 1L;
	
	private long errorCode = 0;
	private String errorText = null;
	private boolean hasError = false;

	public RSUAdvisorySitDataException(String message) {
		super(message);
	}
	
	public RSUAdvisorySitDataException(String message, Throwable cause) {
		super(message, cause);
	}
	
	public static RSUAdvisorySitDataException createInstance(String header, long errorCode) {
		String errorText = ResponseCode.getCodeFormattedText((int)errorCode);
		String message = errorText != null ? 
					String.format("%s completed with error: %s (%d).", header, errorText, errorCode) :
					String.format("%s completed with error code %d.", header, errorCode);
		RSUAdvisorySitDataException ex = new RSUAdvisorySitDataException(message);
		ex.hasError  = true;
		ex.errorText = errorText;
		ex.errorCode = errorCode;
		return ex;
	}
	
	public boolean hasError() {
		return hasError;
	}
	
	public long getErrorCode() {
		return errorCode;
	}
	
	public String getErrorText() {
		return errorText;
	}
	
	public static void main(String[] args) {
		long[] errCodes = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 101, 102, 103, 104, 105, 106, 107, 201, 202, 203, 204, 205 };
		for( long errCode : errCodes ) {
			RSUAdvisorySitDataException ex = createInstance( (errCode%2) != 0 ? "Subscribe Request" : "Cancel Request", errCode);
			if ( ex.hasError ) {
				System.out.printf("Error code: %3d, Error text: '%s', \t%s\n", ex.getErrorCode(), ex.getErrorText(), ex.getMessage());
			} else {
				System.out.println("No error code");	
			}
		}
	}
}
