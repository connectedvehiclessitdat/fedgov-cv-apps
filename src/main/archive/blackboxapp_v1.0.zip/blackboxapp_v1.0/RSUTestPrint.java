package gov.usdot.util.dialog;

import gov.usdot.asn1.generated.j2735.dsrc.DDay;
import gov.usdot.asn1.generated.j2735.dsrc.DFullTime;
import gov.usdot.asn1.generated.j2735.dsrc.DHour;
import gov.usdot.asn1.generated.j2735.dsrc.DMinute;
import gov.usdot.asn1.generated.j2735.dsrc.DMonth;
import gov.usdot.asn1.generated.j2735.dsrc.DYear;
import gov.usdot.asn1.generated.j2735.dsrc.Priority;
import gov.usdot.asn1.generated.j2735.dsrc.TemporaryID;
import gov.usdot.asn1.generated.j2735.semi.AdvisoryBroadcastType;
import gov.usdot.asn1.generated.j2735.semi.BroadcastInstructions;
import gov.usdot.asn1.generated.j2735.semi.Psid;
import gov.usdot.asn1.generated.j2735.semi.RSUAdvisoryBroadcast;
import gov.usdot.asn1.generated.j2735.semi.RsuAdvisorySituationDataBundle;
import gov.usdot.asn1.generated.j2735.semi.SemiDialogID;
import gov.usdot.asn1.generated.j2735.semi.SemiSequenceID;
import gov.usdot.asn1.generated.j2735.semi.TxChannel;
import gov.usdot.asn1.generated.j2735.semi.TxMode;
import gov.usdot.asn1.generated.j2735.semi.RsuAdvisorySituationDataBundle.AsdRecords;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.ByteBuffer;

import org.apache.commons.codec.binary.Hex;

import com.oss.asn1.OctetString;


public class RSUTestPrint{

	public static void main(String[] args){
		buildRsuAdvisorySituationDataBundle();
	}
	
	public static void printToFile(RsuAdvisorySituationDataBundle msg) {

		//String path = System.getProperty("user.dir");
		
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("Please enter file name (include .txt): ");
		String fName = null;
		try {
			fName = input.readLine();
		} catch (IOException e) {
			System.out.println("Could not read name.");
			System.exit(1);
		}
		
		System.out.print("\nEnter path where output file should be stored (no closing slash): ");
		String path = null;
		try {
			path = input.readLine();
		} catch (IOException e) {
			System.out.println("Could not read path.");
			System.exit(1);
		}
		System.out.println("Writing to: " + path + "\\" + fName + "...");
		BufferedWriter out;
		try {
			out = new BufferedWriter(new FileWriter(path + "\\" + fName,true));
			if (msg instanceof RsuAdvisorySituationDataBundle) {
				String output = new String();
				AsdRecords asd = msg.getAsdRecords();
				for (int i = 0; i < asd.getSize(); i++) {
					
					long type = asd.get(i).getBroadcastInst().getBiType().longValue();
					int typeInt = (int)type;
					String typeName = new String();
					switch(typeInt){
					case 0:
						typeName = "SPAT";
						break;
					case 1:
						typeName = "MAP";
						break;
					case 2:
						typeName = "TIM";
						break;
					case 3:
						typeName = "EV";
						break;
					default:
						typeName = "INVALID";
						break;
					}
					
					byte[] psID = asd.get(i).getBroadcastInst().getBiPsid().byteArrayValue();
					String psIDName = Hex.encodeHexString(psID);
					
					byte[] priority = asd.get(i).getBroadcastInst().getBiPriority().byteArrayValue();
					String priorityName = Hex.encodeHexString(priority);
					
					long mode = asd.get(i).getBroadcastInst().getBiTxMode().longValue();
					int modeInt = (int)mode;
					String modeName = new String();
					switch(modeInt){
					case 0:
						modeName = "CONT";
						break;
					case 1:
						modeName = "ALT";
						break;
					default:
						modeName = "INVALID";
						break;
					}
					
					long channel = asd.get(i).getBroadcastInst().getBiTxChannel().longValue();
					int channelInt = (int)channel;
					String channelName = new String();
					switch(channelInt){
					case 0:
						channelName = "CCH";
						break;
					case 1:
						channelName = "SCH";
						break;
					case 2:
						channelName = "172";
						break;
					case 3:
						channelName = "174";
						break;
					case 4:
						channelName = "176";
						break;
					case 5:
						channelName = "178";
						break;
					case 6:
						channelName = "180";
						break;
					case 7:
						channelName = "182";
						break;
					case 8:
						channelName = "184";
						break;
					}		
					
					String startDate = "" + asd.get(i).getBroadcastInst().getBiDeliveryStart().getMonth().intValue()
						+ "/" + asd.get(i).getBroadcastInst().getBiDeliveryStart().getDay().intValue()
						+ "/" + asd.get(i).getBroadcastInst().getBiDeliveryStart().getYear().intValue()
						+ ", " + asd.get(i).getBroadcastInst().getBiDeliveryStart().getHour().intValue()
						+ ":" + asd.get(i).getBroadcastInst().getBiDeliveryStart().getMinute().intValue();
					
					String stopDate = "" + asd.get(i).getBroadcastInst().getBiDelievryStop().getMonth().intValue()
							+ "/" + asd.get(i).getBroadcastInst().getBiDelievryStop().getDay().intValue()
							+ "/" + asd.get(i).getBroadcastInst().getBiDelievryStop().getYear().intValue()
							+ ", " + asd.get(i).getBroadcastInst().getBiDelievryStop().getHour().intValue()
							+ ":" + asd.get(i).getBroadcastInst().getBiDelievryStop().getMinute().intValue();
					
					byte[] advMsg = asd.get(i).getAdvisoryMessage().byteArrayValue();
					String advMsgName = Hex.encodeHexString(advMsg);

					output = ""
						+ "Type=" + typeName + "\n"
						+ "PSID=" + psIDName + "\n"
						+ "Priority=" + priorityName + "\n"
						+ "TxMode=" + modeName + "\n"
						+ "TxChannel=" + channelName + "\n"
						+ "TxInterval=" + asd.get(i).getBroadcastInst().getBiTxInterval() + "\n"
						+ "DeliveryStart=" + startDate + "\n"
						+ "DeliveryStop=" + stopDate + "\n"
						+ "Signature=" + asd.get(i).getBroadcastInst().getBiSignature() + "\n"
						+ "Encryption=" + asd.get(i).getBroadcastInst().getBiEncryption() + "\n"
						+ "Payload=" + advMsgName + "\n";
					out.write(output);
					out.newLine();
				}
				out.newLine();
				out.flush();
				out.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
		
		
		public static void buildRsuAdvisorySituationDataBundle() {
			RsuAdvisorySituationDataBundle bundles = new RsuAdvisorySituationDataBundle();

			bundles.setDialogID(SemiDialogID.advSitDatDistRSE);
			bundles.setSeqID(SemiSequenceID.data);
			bundles.setRequestID(new TemporaryID(ByteBuffer.allocate(4).putInt(1001).array()));
			
			bundles.setRecordCount(3);
			bundles.setBundleCount(3);
			bundles.setBundleID(new TemporaryID(ByteBuffer.allocate(4).putInt(1001).array()));
			AsdRecords dataRecords = new AsdRecords(buildRSUAdvisoryBroadcastArray());
			bundles.setAsdRecords(dataRecords);
			
			printToFile(bundles);
		}

		public static RSUAdvisoryBroadcast buildRSUAdvisoryBroadcast1() {
			RSUAdvisoryBroadcast record1 = new RSUAdvisoryBroadcast();
			String msg1 = new String("Driving like there’s no tomorrow is likely to produce that result.");
			record1.setAdvisoryMessage(convertToOctet(msg1));
			record1.setBroadcastInst(generateBroadcastInstructions());
			
			return record1;
		}
			
		public static RSUAdvisoryBroadcast buildRSUAdvisoryBroadcast2() {
			RSUAdvisoryBroadcast record2 = new RSUAdvisoryBroadcast();
			String msg2 = new String("Click it or ticket.");
			record2.setAdvisoryMessage(convertToOctet(msg2));
			record2.setBroadcastInst(generateBroadcastInstructions());
			
			return record2;
		}

		public static RSUAdvisoryBroadcast buildRSUAdvisoryBroadcast3() {
			RSUAdvisoryBroadcast record3 = new RSUAdvisoryBroadcast();
			String msg3 = new String("Move over or get pulled over.");
			record3.setAdvisoryMessage(convertToOctet(msg3));
			record3.setBroadcastInst(generateBroadcastInstructions());

			return record3;	
		}
		
		public static RSUAdvisoryBroadcast[] buildRSUAdvisoryBroadcastArray() {
			RSUAdvisoryBroadcast[] recordsArray = {buildRSUAdvisoryBroadcast1(),buildRSUAdvisoryBroadcast2(),buildRSUAdvisoryBroadcast3()};
			
			return recordsArray;
		}
		
		private static BroadcastInstructions generateBroadcastInstructions(){
			BroadcastInstructions instr = new BroadcastInstructions();
			
			instr.setBiType(AdvisoryBroadcastType.spatAggregate);
			
			Psid biPsid = new Psid("1234".getBytes());
			instr.setBiPsid(biPsid);
			
			Priority biPriority = new Priority("1".getBytes());
			instr.setBiPriority(biPriority);
			
			instr.setBiTxMode(TxMode.continuous);
			instr.setBiTxChannel(TxChannel.chService);
			instr.setBiTxInterval(10);
			
			//Not a realistic time set?
			DFullTime biDeliveryStart = new DFullTime(new DYear(2013), new DMonth(12), new DDay(9), new DHour(9), new DMinute(30));
			instr.setBiDeliveryStart(biDeliveryStart);
			
			DFullTime biDeliveryStop = new DFullTime(new DYear(2013), new DMonth(12), new DDay(9), new DHour(9), new DMinute(40));
			instr.setBiDelievryStop(biDeliveryStop);
			
			instr.setBiSignature(false);
			instr.setBiEncryption(false);
			
			return instr;
		}
		
		private static OctetString convertToOctet(String message){
			OctetString advisoryMessage = new OctetString(message.getBytes());
			return advisoryMessage;
		}
		
}
