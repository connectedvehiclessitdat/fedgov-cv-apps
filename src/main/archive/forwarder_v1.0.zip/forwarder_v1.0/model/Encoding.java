package gov.usdot.cv.model;

public enum Encoding {

	None, Base16, Base64

}
