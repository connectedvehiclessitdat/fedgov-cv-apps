package gov.usdot.cv;

import java.net.DatagramPacket;
import java.util.Arrays;


import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet6Address;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;


import javax.xml.bind.DatatypeConverter;

//import org.apache.log4j.Logger;
//import com.saic.rtws.transport.AbstractTransportService;

import gov.usdot.cv.UDPForwarderService;
import gov.usdot.cv.model.Encoding;

public class UDPMessageForwarderProcessor implements Runnable {

	//private static final Logger log = Logger.getLogger(ForSimpleUDPMessageProcessor.class);


        private static MessageDigest messageDigest = null;

        Thread executeTrasportThread = null;

        private int sendPort;
        private int maxPacketSize;

        private long started;




	private DatagramPacket packet;
	private UDPForwarderService reciever;
	private Encoding encoding = Encoding.None;

	public UDPMessageForwarderProcessor(DatagramPacket packet, UDPForwarderService reciever) {
		this.packet = packet;
		this.reciever = reciever;
		if ( reciever != null && reciever instanceof UDPForwarderService )
			encoding = ((UDPForwarderService)reciever).getEncoding();
	}

	@Override
	public void run() {
		if ( packet != null && reciever != null ) {
			final int length = packet.getLength();
			if ( length <= 0 )
				return;
		

			final byte[] data = packet.getData();
			final int offset = packet.getOffset();


			String	packetDataA = new String(data, offset, length);
			String	packetDataB = "ipv6Addr"+packetDataA; 
			String	packetDataC = DatatypeConverter.printBase64Binary(packetDataB.getBytes());
			System.out.println(packetDataC);

			try {
				String packetData = null;
				switch(encoding) {
					case Base16:
						packetData = DatatypeConverter.printHexBinary( Arrays.copyOfRange(data, offset, length) );
						packetDataC = DatatypeConverter.printHexBinary(packetDataB.getBytes());
						break;
					case Base64:
						packetData = DatatypeConverter.printBase64Binary( Arrays.copyOfRange(data, offset, length) );
						packetDataC = DatatypeConverter.printBase64Binary(packetDataB.getBytes());
						break;
					default:
						packetData = new String(data, offset, length);
						packetDataC = packetDataB;
						break;
				}
				//log.debug(String.format("processing packet: '%s'", packetData));
				//reciever.SendJMSMessage(packetData);
				System.out.println("packetData");
				System.out.println(packetData);
				System.out.println(packetDataC);
				System.out.println("packetData");


                System.out.println(packet.getSocketAddress().toString());
                System.out.println(packet.getAddress().toString());


				sendUdpPacketB(packet);
				//sendUdpPacket(packetData);
				//sendUdpPacket(packetDataC);



			} catch (Exception ex ) {
				//log.error("Caught exception while processing a packet", ex );
			}
		}
	}

		private void sendUdpPacket(String packetPayload) {
                InetAddress ipAddress = null;
                try {
                        //ipAddress = Inet6Address.getByName("localhost");
                        //ipAddress = Inet6Address.getByName("54.82.140.15");
                        ipAddress = Inet6Address.getByName("54.204.100.112");
                } catch (UnknownHostException ex) {
			System.out.println("got local");
			System.out.println(ipAddress);
                        //log.error("Couldn't get local host by name", ex);
                        //assertFalse(true);
                }


		System.out.println("preparing to send");
//		Thread.sleep(1000);
                DatagramSocket socket = null;
                started = System.currentTimeMillis();
                try {
			System.out.println("dgs ");
                        socket = new DatagramSocket();
			System.out.println("dgsB ");
                        //for( int i = 0; i < packetsToSend; i++ ) {
                 //DataPacket dataPacket = new DataPacket(1,packetPayload);
                                //byte[] packet = dataPacket.getBytes();
                                //byte[] packet = dataPacket.getBytes();
                                //byte[] packet = fjf.getBytes();
				//byte[] packet = new byte[1024];
				byte[] packet = new byte[65535];

//  final private int DEFAULT_MAX_PACKET_SIZE = 65535;

                              //  byte[] packet = packetPayload.getBytes();
                               //@@@
			packet = packetPayload.getBytes();
                       //        packet = fjf.getBytes();
	
			System.out.println("dgsC ");




                                //DatagramPacket datagramPacket = new DatagramPacket(packet, packet.length, ipAddress, sendPort);
                       DatagramPacket datagramPacket = new DatagramPacket(packet, packet.length, ipAddress, 46751);

			System.out.println("dgsD ");
                                 socket.send(datagramPacket);
			System.out.println("dgsE ");
                                try {
                                        Thread.sleep(10);
                                } catch (InterruptedException igonore) {
			System.out.println("send exception ");
                                }
                       // }
                } catch (IOException ex) {
                        //log.error("Couldn't send datagram packet", ex);
			System.out.println("io send exception ");
			ex.printStackTrace();
                        //assertFalse(true);
                } finally {
                        if ( socket != null ) {
                                if ( !socket.isClosed() )
                                        socket.close();
                                socket = null;
                        }
                }
        }




		private void sendUdpPacketB(DatagramPacket datagramPacket) {
                InetAddress ipAddress = null;
                try {
                        //ipAddress = Inet6Address.getByName("localhost");
                        //ipAddress = Inet6Address.getByName("54.82.140.15");
                        ipAddress = Inet6Address.getByName("54.87.129.17");
                } catch (UnknownHostException ex) {
			System.out.println(ipAddress);
                        //log.error("Couldn't get local host by name", ex);
                        //assertFalse(true);
                }


		System.out.println("preparing to send");
//		Thread.sleep(1000);
                DatagramSocket socket = null;
                started = System.currentTimeMillis();
                try {
			System.out.println("dgs ");
                        socket = new DatagramSocket();
			System.out.println("dgsB ");
			System.out.println("dgsC ");
					//datagramPacket.setSocketAddress(InetSocketAddress.createUnresolved("54.204.100.112", 46751));


				byte[] packet = new byte[65535];
				byte[] packetOut = new byte[65535];





	//packet = (datagramPacket.getData());

	//	arraycopy(Object src, int srcPos, Object dest, int destPos, int length);
	//System.arraycopy(packet, 0, packetOut, 1, packet.length-1);
	//System.arraycopy(packet, 0, packetOut, 0, packet.length);

	//@@	System.arraycopy(datagramPacket, datagramPacket.getOffset(), packetOut, 0, datagramPacket.getLength());


	//System.arraycopy(packet.getData(), packet.getOffset(), data, 0, packet.getLength());


	/*
			int cntr = 0;
                        for (byte bt: packet) {
				System.out.println(cntr);
				System.out.println(bt);
				cntr++;
				
				}

	*/



				//datagramPacket.setData(packetOut,0,65535);


				//datagramPacket.setData(packet);
			//	datagramPacket.setLength(packetOut.length);
			
			//	datagramPacket.setData(packetOut);
					datagramPacket.setAddress(ipAddress);
					datagramPacket.setPort(46751);
                       ///DatagramPacket datagramPacket = new DatagramPacket(packet, packet.length, ipAddress, 46751);


                               socket.send(datagramPacket);

//			datagramPacket.setData(packetOut);

                             //  socket.send(datagramPacket);

			System.out.println("dgsE ");
                                try {
                                        Thread.sleep(10);
                                } catch (InterruptedException igonore) {
			System.out.println("send exception ");
                                }
                       // }
                } catch (IOException ex) {
                        //log.error("Couldn't send datagram packet", ex);
			System.out.println("io send exception ");
			ex.printStackTrace();
                } finally {
                        if ( socket != null ) {
                                if ( !socket.isClosed() )
                                        socket.close();
                                socket = null;
                        }
                }
        }






}
